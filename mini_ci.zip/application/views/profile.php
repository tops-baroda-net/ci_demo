<h2>WELCOME : <?php echo $this->session->userdata('reg_fname');  ?> </h2>
<h2><?php echo $this->session->userdata('reg_lname');  ?> </h2>
<h2><?php echo $this->session->userdata('reg_email');  ?> </h2>

<h2><?php echo $this->session->userdata('reg_dob');  ?> </h2>
