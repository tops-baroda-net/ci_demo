  <script src="<?php echo base_url(); ?>Admin/assets/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>Admin/assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>Admin/assets/plugins/metisMenu/jquery.metisMenu.js"></script>
     <script src="<?php echo base_url(); ?>Admin/assets/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url(); ?>Admin/assets/scripts/siminta.js"></script>
<script src="<?php echo base_url(); ?>Admin/assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url(); ?>Admin/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>