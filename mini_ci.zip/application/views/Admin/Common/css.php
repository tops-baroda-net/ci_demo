<link href="<?php echo base_url(); ?>Admin/assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>Admin/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>Admin/assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="<?php echo base_url(); ?>Admin/assets/css/style.css" rel="stylesheet" />
      <link href="<?php echo base_url(); ?>Admin/assets/css/main-style.css" rel="stylesheet" />

  <link href="<?php echo base_url(); ?>Admin/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
