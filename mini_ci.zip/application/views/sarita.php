<h2> sarita </h2>



<form method="POST" action="<?php echo base_url() ?>welcome/adddata" >  

<label> fname </label>
<input type="text" name="fname" ><br>

<label> lname </label>
<input type="text" name="lname" ><br>

<label> Email </label>
<input type="email" name="email" ><br>

<label> password </label>
<input type="password" name="password" ><br>

<label> DOB </label>
<input type="date" name="dob" ><br> 
<input type="submit" name="submit" value="Registratrion">

  </form>