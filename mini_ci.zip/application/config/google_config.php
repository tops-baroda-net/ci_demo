<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="483693149249-rjl1e0uv2nabgn8r579gs06do7k18r3q.apps.googleusercontent.com";
$config['google_client_secret']="nyBBRjRD-rH4BztK8tiRx0VQ";
$config['google_redirect_url']=base_url().'auth/oauth2callback';

